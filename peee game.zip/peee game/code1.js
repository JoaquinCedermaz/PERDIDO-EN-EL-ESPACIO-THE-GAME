gdjs.StartCode = {};
gdjs.StartCode.GDBackgroundObjects1= [];
gdjs.StartCode.GDBackgroundObjects2= [];
gdjs.StartCode.GDPlayObjects1= [];
gdjs.StartCode.GDPlayObjects2= [];

gdjs.StartCode.conditionTrue_0 = {val:false};
gdjs.StartCode.condition0IsTrue_0 = {val:false};
gdjs.StartCode.condition1IsTrue_0 = {val:false};
gdjs.StartCode.condition2IsTrue_0 = {val:false};


gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.StartCode.GDPlayObjects1});
gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.StartCode.GDPlayObjects1});
gdjs.StartCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.StartCode.GDPlayObjects1);

gdjs.StartCode.condition0IsTrue_0.val = false;
gdjs.StartCode.condition1IsTrue_0.val = false;
{
gdjs.StartCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDPlayObjects1Objects, runtimeScene, true, false);
}if ( gdjs.StartCode.condition0IsTrue_0.val ) {
{
gdjs.StartCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.StartCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main", true);
}}

}


{


{
{gdjs.deviceSensors.motion.activateMotionSensor();
}{gdjs.deviceSensors.orientation.deactivateOrientationSensor();
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.StartCode.GDPlayObjects1);

gdjs.StartCode.condition0IsTrue_0.val = false;
{
gdjs.StartCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDPlayObjects1Objects, runtimeScene, true, false);
}if (gdjs.StartCode.condition0IsTrue_0.val) {
/* Reuse gdjs.StartCode.GDPlayObjects1 */
{for(var i = 0, len = gdjs.StartCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.StartCode.GDPlayObjects1[i].setColor("144;19;254");
}
}}

}


};

gdjs.StartCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.StartCode.GDBackgroundObjects1.length = 0;
gdjs.StartCode.GDBackgroundObjects2.length = 0;
gdjs.StartCode.GDPlayObjects1.length = 0;
gdjs.StartCode.GDPlayObjects2.length = 0;

gdjs.StartCode.eventsList0(runtimeScene);
return;

}

gdjs['StartCode'] = gdjs.StartCode;
